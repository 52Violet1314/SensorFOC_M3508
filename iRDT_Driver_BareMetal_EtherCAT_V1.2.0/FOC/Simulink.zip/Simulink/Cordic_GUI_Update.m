function Cordic_GUI_Update(gcbh,param)
nowIsRotate= find_system(gcb,'LookUnderMasks','on','FollowLinks','on','BlockType','Inport','Name','Angle');%�жϵ�ǰ����ģʽ
currentBlockPath = getfullname(gcbh);%��ȡ��ǰģ���·�������������õ���Ҫ�޸�block��
switch(param)
    case 'paramCordicFunction'
        if strcmp(get_param(gcbh,'paramCordicFunction'),'Circular')
            set_param(gcbh,'paramFunctionBool','1');
        else%Hyperbolic
            set_param(gcbh,'paramFunctionBool','0');
        end
    case 'paramCordicMode'
        if strcmp(get_param(gcbh,'paramCordicMode'),'Vector')
            SetPortAction_Vector(gcbh,currentBlockPath,nowIsRotate);
        else%Rotate
            SetPortAction_Rotate(gcbh,currentBlockPath,nowIsRotate);
        end
    case 'paramInitValueAngle'
        if strcmp(get_param(gcbh,'paramCordicMode'),'Vector')
            InitValueAngle=get_param(gcbh,param);
            set_param(strcat(currentBlockPath,'/Angle'),'Value',InitValueAngle,'OutDataTypeStr','fixdt(0,16,0)');%����const�������ͺ�ֵ
        end
end
end
% end

function SetPortAction_Vector(gcbh,currentBlockPath,nowIsRotate)
    set_param(gcbh,'paramModeBool','1');
    if ~isempty(nowIsRotate)
        replace_block(currentBlockPath,'FollowLinks', 'on','Name','Angle','Constant','noprompt');%,'noprompt'�滻�˿�ΪConstant
        replace_block(currentBlockPath,'FollowLinks', 'on','Name','Yf','Terminator','noprompt');
        replace_block(currentBlockPath,'FollowLinks', 'on','Name','Atan','Outport','noprompt');
    end
    %*******input setting*********%
    InitValueAngle=get_param(gcbh,'paramInitValueAngle');
    set_param(strcat(currentBlockPath,'/Angle'),'Value',InitValueAngle,'OutDataTypeStr','fixdt(0,16,0)');
    p=Simulink.Mask.get(gcbh);%��ȡMask����
    p2=p.Parameters(5);
    p2.set('Enabled','on');%�ر�Angle�ĳ�ʼֵ
    %*******output setting*********%
    set_param(strcat(currentBlockPath,'/Atan'),'OutDataTypeStr','fixdt(0,16,0)');
    set_param(strcat(currentBlockPath,'/Atan'),'AttributesFormatString','%<OutDataTypeStr>');%��ʾ��������
end
function SetPortAction_Rotate(gcbh,currentBlockPath,nowIsRotate)
    set_param(gcbh,'paramModeBool','0');
    if isempty(nowIsRotate)
        replace_block(currentBlockPath,'FollowLinks', 'on','Name','Angle','Inport','noprompt');
        replace_block(currentBlockPath,'FollowLinks', 'on','Name','Xf','Outport','noprompt');
        replace_block(currentBlockPath,'FollowLinks', 'on','Name','Yf','Outport','noprompt');
        replace_block(currentBlockPath,'FollowLinks', 'on','Name','Atan','Terminator','noprompt');
    end
    %*******input setting*********%
    set_param(strcat(currentBlockPath,'/Angle'),'OutDataTypeStr','fixdt(0,16,0)');
    set_param(strcat(currentBlockPath,'/Angle'),'AttributesFormatString','%<OutDataTypeStr>');
    p=Simulink.Mask.get(gcbh);%��ȡMask����
    p2=p.Parameters(5);
    p2.set('Enabled','off');%�ر�Angle�ĳ�ʼֵ
    %*******output setting*********%
    set_param(strcat(currentBlockPath,'/Xf'),'OutDataTypeStr','fixdt(1,32,paramCQF)');
    set_param(strcat(currentBlockPath,'/Xf'),'AttributesFormatString','%<OutDataTypeStr>');
    set_param(strcat(currentBlockPath,'/Yf'),'OutDataTypeStr','fixdt(1,32,paramCQF)');
    set_param(strcat(currentBlockPath,'/Yf'),'AttributesFormatString','%<OutDataTypeStr>');
    
end
%% �滻�˿�
% position1=get_param(Input_1,'Position');%����[left,top,right,bottom]
% handle = add_block('simulink/Sources/Ground', 'FOCfilter_ui/FOC_Filter/Ground','Position',position1);%�´�������ǰ��ɾ��
% handle = add_block('simulink/Sources/Ground', 'FOCfilter_ui/FOC_Filter/Ground','MakeNameUnique', 'on');%�´����ӻ��Զ�������
% set_param(handle,'Position',position1);
% get_param('FOCfilter_ui/FOC_Filter/Ground1','Position')
% replace_block('sys', 'old_blk', 'new_blk')

% systemName = gcs;
% index=strfind(systemName,'/');
% if ~isempty(index)
%     systemName=a(1:index(1)-1);
% end
% isLibrary = bdIsLibrary(systemName);
% %%********��ֹ����ʱ�˿ڶϿ�**********%%
% if isLibrary==true
%     modelState='stopped';%library �����޸�
% else%not library
%     modelState=get_param(systemName,'SimulationStatus');%model�£�����stop״̬�²����޸�
% end
% modelState=get_param(systemName,'SimulationStatus');%model�£�����stop״̬�²����޸�
